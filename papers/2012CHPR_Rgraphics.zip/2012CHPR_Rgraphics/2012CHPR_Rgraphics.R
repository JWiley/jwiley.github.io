### R code from vignette source '2012CHPR_Rgraphics.rnw'

###################################################
### code chunk number 1: 2012CHPR_Rgraphics.rnw:37-38
###################################################
options(width = 60)


###################################################
### code chunk number 2: 2012CHPR_Rgraphics.rnw:50-71
###################################################
## base <- ifelse(grepl("PC", Sys.info()['nodename']),
##   "S:/", "~/Documents/")
## setwd(file.path(base, "Workshops/HPRC_RGraphics"))
infert <- within(infert, {
  case <- factor(case, labels = c("Control", "Case"))
  spontaneous <- factor(spontaneous, labels = c("0", "1", "2+"))
})

require(ggplot2)
require(scales)
p <-
  ggplot(infert, aes(x = "", fill = spontaneous)) +
  geom_bar(width = 1, position = "fill") +
  coord_polar(theta = "y") +
  facet_grid(case ~ education, margins = TRUE)

print(p +
  labs(x = "Condition", y = "Education") +
  scale_y_continuous(labels = percent) +
  scale_fill_discrete(name = "Number of \n abortions") +
  opts(title = "Number of abortions conditional on condition and education \n (with marginal totals)"))


###################################################
### code chunk number 3: 2012CHPR_Rgraphics.rnw:180-186
###################################################
x <- c(1, 2, 3, 1, 2, 3)
class(x)
print(x)
x <- factor(x)
class(x)
print(x)


###################################################
### code chunk number 4: 2012CHPR_Rgraphics.rnw:215-216
###################################################
str(infert)


###################################################
### code chunk number 5: 2012CHPR_Rgraphics.rnw:293-302
###################################################
require(rJava)
require(xlsx)
require(reshape2)
dat <- read.xlsx(file = "barchart.xlsx", 1)
ldat <- melt(dat)
colnames(ldat)[1] <- "group"
p <- ggplot(ldat,
  aes(x = variable, y = value, fill = group)) +
  geom_bar(stat = "identity", position = "dodge")


###################################################
### code chunk number 6: 2012CHPR_Rgraphics.rnw:319-320
###################################################
print(p); presplots <- list(bar1 = p)


###################################################
### code chunk number 7: 2012CHPR_Rgraphics.rnw:336-342
###################################################
p <-
  p +
  labs(x = "Months", y = "") +
  scale_fill_grey(name = "Hospital") +
  opts(title = "Monthly Hospital Expenditures") +
  theme_bw()


###################################################
### code chunk number 8: 2012CHPR_Rgraphics.rnw:357-358
###################################################
print(p)


###################################################
### code chunk number 9: 2012CHPR_Rgraphics.rnw:376-381
###################################################
p <-
  p +
  scale_x_discrete(breaks = paste0("x", 1:6), labels =
  months(as.Date(paste0("2012/", 1:6, "/01"), "%Y/%m/%d"))) +
  opts(axis.text.x = theme_text(angle = 45))


###################################################
### code chunk number 10: 2012CHPR_Rgraphics.rnw:394-395
###################################################
print(p)


###################################################
### code chunk number 11: 2012CHPR_Rgraphics.rnw:407-418
###################################################
dat2 <- read.xlsx(file = "barchart2.xlsx", 1)
ldat2 <- na.omit(melt(dat2))
colnames(ldat2)[1] <- "group"
cols <- colorRamp(c("lightblue", "blue"))(
  seq(0, 1, length.out = 11))
cols <- rgb(cols[, 1], cols[, 2], cols[, 3],
  maxColorValue = 255)
p <- ggplot(ldat2,
  aes(x = variable, y = value, fill = group)) +
  geom_bar(stat = "identity", position = "stack") +
  scale_fill_manual(values = cols)


###################################################
### code chunk number 12: 2012CHPR_Rgraphics.rnw:435-436
###################################################
print(p)


###################################################
### code chunk number 13: 2012CHPR_Rgraphics.rnw:450-455
###################################################
p <- ggplot(ldat,
  aes(x = "", y = value, fill = group)) +
  geom_bar(width=1, position = "fill") +
  coord_polar(theta = "y") +
  facet_wrap(~variable)


###################################################
### code chunk number 14: 2012CHPR_Rgraphics.rnw:470-471
###################################################
print(p)


###################################################
### code chunk number 15: 2012CHPR_Rgraphics.rnw:485-491
###################################################
require(grid) # has viewport function
vp <- viewport(width = .5, height = .3, x = 1, y = 0,
  just = c("right", "bottom"))
p <- p +
  opts(title = "Pie chart with Inset Bar chart\n",
    plot.margin = unit(c(-5, 0, 0, 0), "lines"))


###################################################
### code chunk number 16: 2012CHPR_Rgraphics.rnw:508-509
###################################################
print(p); print(presplots$bar1, vp = vp)


###################################################
### code chunk number 17: 2012CHPR_Rgraphics.rnw:525-533
###################################################
dat3 <- read.xlsx(file = "linechart.xlsx",
  1, header = FALSE)
ldat3 <- melt(dat3)
colnames(ldat3)[1] <- "group"
ldat3$variable <- as.numeric(ldat3$variable)

p <- ggplot(ldat3, aes(x = variable, y = value,
  colour = group))


###################################################
### code chunk number 18: 2012CHPR_Rgraphics.rnw:547-548
###################################################
print(p + geom_line())


###################################################
### code chunk number 19: 2012CHPR_Rgraphics.rnw:562-563
###################################################
print(p + geom_point())


###################################################
### code chunk number 20: 2012CHPR_Rgraphics.rnw:576-577
###################################################
print(p + geom_line() + geom_point())


###################################################
### code chunk number 21: 2012CHPR_Rgraphics.rnw:590-592
###################################################
p <- p + geom_line() + geom_point(aes(shape = group))
print(p)


###################################################
### code chunk number 22: 2012CHPR_Rgraphics.rnw:606-608
###################################################
p <- p + opts(legend.key.width = unit(1, "cm"))
print(p)


###################################################
### code chunk number 23: 2012CHPR_Rgraphics.rnw:622-634
###################################################
require(maps)
require(mapproj)

states <- map_data("state")[,
  c("long", "lat", "group", "order", "region")]
colnames(states)[5] <- "state"

## original data source
## dat <- read.csv("http://www.census.gov/popest/data/
##  national/totals/2011/files/NST_EST2011_ALLDATA.csv")

dat <- read.csv("popdata.csv")


###################################################
### code chunk number 24: 2012CHPR_Rgraphics.rnw:647-654
###################################################
births <- with(dat, {
  data.frame(state = tolower(NAME),
  kbirths2011 = BIRTHS2011/1000,
  mpop2010 = CENSUS2010POP/1000000)
})

births <- subset(births, state %in% states$state)


###################################################
### code chunk number 25: 2012CHPR_Rgraphics.rnw:667-678
###################################################
chloropleth <- merge(states, births, "state")
chloropleth <- chloropleth[order(chloropleth$order), ]

p <- ggplot(chloropleth, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = kbirths2011)) +
  geom_polygon(data = states, colour = "white", fill=NA) +
  scale_fill_gradientn(name = "Births in\nthousands",
    guide = guide_colorbar(),
    colours = c("blue", "red"),
    limits = c(0, 550)) +
  coord_map(projection = "mercator")


###################################################
### code chunk number 26: 2012CHPR_Rgraphics.rnw:694-695
###################################################
print(p)


###################################################
### code chunk number 27: 2012CHPR_Rgraphics.rnw:708-717
###################################################
tmp <- chloropleth[cumsum(rle(chloropleth$state)$lengths),]

p <- p +
  labs(x = "Longitude", y = "Latitude") +
  geom_point(data = tmp,
    aes(long, lat, size = mpop2010, group = 1)) +
  scale_size_continuous(guide = FALSE, range = c(4, 10)) +
  opts(title =
  "2011 US Births, 2010 population shown in bubbles\n")


###################################################
### code chunk number 28: 2012CHPR_Rgraphics.rnw:731-732
###################################################
print(p)


###################################################
### code chunk number 29: 2012CHPR_Rgraphics.rnw:754-764
###################################################
## install.packages("BiocInstaller", repos =
## "http://www.bioconductor.org/packages/2.11/bioc")
## require(BiocInstaller)
## biocLite("ALL")

require(ALL)
require("gplots")

data("ALL")
x <- exprs(ALL)[1:60, ]


###################################################
### code chunk number 30: 2012CHPR_Rgraphics.rnw:778-779
###################################################
heatmap(x)


###################################################
### code chunk number 31: 2012CHPR_Rgraphics.rnw:825-828
###################################################
heatmap.2(x, scale = "row", symkey=TRUE,
  col = colorpanel(256, "blue", "black", "yellow"),
  trace = "none", cexCol = 0.4, cexRow = 0.5)


